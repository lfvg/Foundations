struct pergunta {
    let perg:String
    let resposta:String
    let err1:String
    let err2:String
}
var pontuacao = 0
func unpack(v:Optional<String>) -> String{
    
    if let k = v{
            return k
    }
    return ""
}

var perguntas = [pergunta(perg:"Qual o melhor professor do Foundations", resposta: "Kiev", err1: "Fernando Castor", err2: "Cristiano"), pergunta(perg:"Pode levar o Mac pra casa", resposta: "Não seu mamão!", err1: "Sim", err2: "Claro"), pergunta(perg:"Qual a linguagem de origramacão a gente aprende", resposta: "Swift", err1: "Java", err2: "C#"), pergunta(perg:"Sim", resposta: "Sim", err1: "Não", err2: "Talvez")]

print("Escreva as respostas:")

for p in perguntas{
    print("Pergunta " + "\(p.perg)")
    print("1)" + "\(p.resposta)")
    print("2)" + "\(p.err1)")
    print("3)" + "\(p.err1)")
    let r = unpack(v:readLine())
    if r == p.resposta{
        pontuacao+=1
        print("Acertou mizeravi!")
    }
    else{
        print("Trump: WRONG!!")
    }
}
print("Seu score foi: " + "\(pontuacao)")
